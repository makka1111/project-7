// Получаем элементы формы и сообщения
const routeForm = document.getElementById('routeForm');
const statusMessage = document.getElementById('statusMessage');

// Событие при отправке формы
routeForm.addEventListener('submit', function (e) {
  e.preventDefault();

  // Получаем значения начальной и конечной точек
  const start = document.getElementById('start').value.trim();
  const end = document.getElementById('end').value.trim();

  if (start && end) {
    // Создаём объект маршрута
    const route = { start, end, date: new Date().toLocaleString() };

    // Загружаем существующие маршруты из LocalStorage
    let routes = JSON.parse(localStorage.getItem('routes')) || [];

    // Добавляем новый маршрут в массив
    routes.push(route);

    // Сохраняем обновлённый массив маршрутов в LocalStorage
    localStorage.setItem('routes', JSON.stringify(routes));

    // Отображаем сообщение о сохранении
    statusMessage.textContent = 'Маршрут сохранён!';
    statusMessage.style.display = 'block';

    // Очищаем поля ввода
    document.getElementById('start').value = '';
    document.getElementById('end').value = '';

    // Скрываем сообщение через 3 секунды
    setTimeout(() => {
      statusMessage.style.display = 'none';
    }, 3000);
  } else {
    alert('Пожалуйста, заполните начальную и конечную точки!');
  }
});

// Инициализация карты
const map = L.map('map').setView([55.7558, 37.6173], 10); // Центр карты (Москва)

// Подключение базового слоя карты OpenStreetMap
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution:
    '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
}).addTo(map);

// Функция для построения маршрута
function createRoute(start, end) {
  L.Routing.control({
    waypoints: [L.latLng(start.lat, start.lng), L.latLng(end.lat, end.lng)],
    routeWhileDragging: true,
  }).addTo(map);
}

// Обработчик формы для построения маршрута
document.getElementById('routeForm').addEventListener('submit', function (e) {
  e.preventDefault();

  // Получение начальной и конечной точек
  const startAddress = document.getElementById('start').value.trim();
  const endAddress = document.getElementById('end').value.trim();

  if (startAddress && endAddress) {
    // Геокодирование адресов через Nominatim API
    Promise.all([geocode(startAddress), geocode(endAddress)])
      .then(([startCoords, endCoords]) => {
        if (startCoords && endCoords) {
          createRoute(startCoords, endCoords);
        } else {
          alert('Не удалось найти один из адресов.');
        }
      })
      .catch(() => {
        alert('Ошибка при обработке адресов.');
      });
  } else {
    alert('Пожалуйста, введите начальную и конечную точки.');
  }
});

// Функция для геокодирования адреса через Nominatim API
function geocode(address) {
  return fetch(
    `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(address)}`,
  )
    .then(response => response.json())
    .then(data => {
      if (data && data.length > 0) {
        return {
          lat: parseFloat(data[0].lat),
          lng: parseFloat(data[0].lon),
        };
      } else {
        return null;
      }
    });
}
