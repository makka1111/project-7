// Получаем список маршрутов из LocalStorage
const savedRoutes = JSON.parse(localStorage.getItem('routes')) || [];
const list = document.getElementById('savedRoutes');

// Проверяем, есть ли сохранённые маршруты
if (savedRoutes.length > 0) {
  savedRoutes.forEach(route => {
    const li = document.createElement('li');
    li.innerHTML = `<strong>От:</strong> ${route.start} <br> 
                        <strong>До:</strong> ${route.end} <br> 
                        <strong>Дата:</strong> ${route.date}`;
    li.classList.add('saved-route');
    list.appendChild(li);
  });
} else {
  const noRoutesMessage = document.createElement('p');
  noRoutesMessage.textContent = 'Нет сохранённых маршрутов.';
  list.appendChild(noRoutesMessage);
}
